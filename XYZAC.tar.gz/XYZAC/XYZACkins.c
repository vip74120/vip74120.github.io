/********************************************************************
* Description: XYZACkins.c
*   Kinematics for  5 axis mill named 'XYZAC'.
*   This mill has a tilting table (A axis) and horizontal rotary
*   mounted to the table (C axis).
*
* Author: Rudy du Preez
* License: GPL Version 2
*    
********************************************************************/

#include "kinematics.h"		/* these decls */
#include "posemath.h"
#include "hal.h"
#include "rtapi.h"
#include "rtapi_math.h"

struct haldata {
    hal_float_t *Z_offset;
    hal_float_t *Y_offset;
} *haldata;

int kinematicsForward(const double *joints,
		      EmcPose * pos,
		      const KINEMATICS_FORWARD_FLAGS * fflags,
		      KINEMATICS_INVERSE_FLAGS * iflags)
{
    double dz = *(haldata->Z_offset);
    double dy = *(haldata->Y_offset);
    double c_rad = joints[5]*M_PI/180;
    double a_rad = joints[3]*M_PI/180;

    pos->tran.x = joints[0]*cos(c_rad) + 
                  (joints[1]+dy)*sin(c_rad)*cos(a_rad) +
                  (joints[2]+dz)*sin(c_rad)*sin(a_rad) -
                  sin(c_rad)*dy;

    pos->tran.y = -joints[0]*sin(c_rad) + 
                   (joints[1]+dy)*cos(c_rad)*cos(a_rad) +
                   (joints[2]+dz)*cos(c_rad)*sin(a_rad) -
                   cos(c_rad)*dy;

    pos->tran.z = -(joints[1]+dy)*sin(a_rad) + 
                   (joints[2]+dz)*cos(a_rad) -
                   dz;

    pos->a = joints[3];
    pos->b = joints[4];
    pos->c = joints[5];

    return 0;
}

int kinematicsInverse(const EmcPose * pos,
		      double *joints,
		      const KINEMATICS_INVERSE_FLAGS * iflags,
		      KINEMATICS_FORWARD_FLAGS * fflags)
{       
    double dz = *(haldata->Z_offset);
    double dy = *(haldata->Y_offset);
    double c_rad = pos->c*M_PI/180;
    double a_rad = pos->a*M_PI/180;

    joints[0] = pos->tran.x*cos(c_rad) - 
                pos->tran.y*sin(c_rad);

    joints[1] = pos->tran.x*sin(c_rad)*cos(a_rad) +
                pos->tran.y*cos(c_rad)*cos(a_rad) -
                (pos->tran.z+dz)*sin(a_rad) -
                (1-cos(a_rad))*dy;

    joints[2] = pos->tran.x*sin(c_rad)*sin(a_rad) + 
                pos->tran.y*cos(c_rad)*sin(a_rad) +
                (pos->tran.z+dz)*cos(a_rad) +
                sin(a_rad)*dy - dz;

    joints[3] = pos->a;
    joints[4] = pos->b;
    joints[5] = pos->c;

    return 0;
}

KINEMATICS_TYPE kinematicsType()
{
    return KINEMATICS_BOTH;
}

#include "rtapi.h"		/* RTAPI realtime OS API */
#include "rtapi_app.h"		/* RTAPI realtime module decls */
#include "hal.h"

EXPORT_SYMBOL(kinematicsType);
EXPORT_SYMBOL(kinematicsInverse);
EXPORT_SYMBOL(kinematicsForward);
MODULE_LICENSE("GPL");

int comp_id;
int rtapi_app_main(void) {
    int res = 0;
    comp_id = hal_init("XYZACkins");
    if(comp_id < 0) return comp_id;

    haldata = hal_malloc(sizeof(struct haldata));

    if((res = hal_pin_float_new("XYZACkins.Y-offset", HAL_IO, &(haldata->Y_offset), comp_id)) < 0) goto error;
    if((res = hal_pin_float_new("XYZACkins.Z-offset", HAL_IO, &(haldata->Z_offset), comp_id)) < 0) goto error;

    hal_ready(comp_id);
    return 0;

error:
    hal_exit(comp_id);
    return res;

}

void rtapi_app_exit(void) { hal_exit(comp_id); }
