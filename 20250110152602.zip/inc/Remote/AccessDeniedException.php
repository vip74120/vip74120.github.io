<?php

namespace dokuwiki\Remote;

/**
 * Class AccessDeniedException
 */
class AccessDeniedException extends RemoteException
{
}
